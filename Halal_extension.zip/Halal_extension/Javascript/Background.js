chrome.storage.sync.set({ Toggled: true }).then(() => {
    console.log("Toggle variable set!");
});
